const app = Promise.resolve(require('./dist/lofi-code/server/main.js')).then(server => server.app());
exports.handle = (req,res) => app.then(it => it(req,res));
