import{b as _t,e as Pn,f as Yt,h as An,j as Gt,k as En,q as Tn,s as Nn}from"./chunk-HIGCNIJI.js";import{$ as ye,A as ln,Aa as nt,Ab as ke,Ba as it,Da as Ut,Fb as N,Gb as R,Ha as at,Hb as Wt,I as fn,Ia as L,Ib as kt,J as un,Jb as kn,Ma as bn,Mb as U,N as dn,Nb as E,Ob as Cn,P as mn,Pb as _n,Q as hn,Ub as Ct,Vb as In,Xb as On,Y as pn,_a as yn,a as ve,aa as $t,ac as Ce,db as B,eb as g,ec as Sn,fa as _,fc as Mn,ga as I,h as on,ia as gn,j as be,jb as wn,ka as X,m as lt,n as Rt,pa as we,q as sn,qa as K,r as cn,ra as O,sa as ft,ta as vn,ub as ut,vb as Ht,w as zt,wb as M,xc as Vt,yb as xe,za as $,zb as xn}from"./chunk-RQANKSTU.js";var _e;try{_e=typeof Intl<"u"&&Intl.v8BreakIterator}catch{_e=!1}var Dn=(()=>{let e=class e{constructor(n){this._platformId=n,this.isBrowser=this._platformId?En(this._platformId):typeof document=="object"&&!!document,this.EDGE=this.isBrowser&&/(edge)/i.test(navigator.userAgent),this.TRIDENT=this.isBrowser&&/(msie|trident)/i.test(navigator.userAgent),this.BLINK=this.isBrowser&&!!(window.chrome||_e)&&typeof CSS<"u"&&!this.EDGE&&!this.TRIDENT,this.WEBKIT=this.isBrowser&&/AppleWebKit/i.test(navigator.userAgent)&&!this.BLINK&&!this.EDGE&&!this.TRIDENT,this.IOS=this.isBrowser&&/iPad|iPhone|iPod/.test(navigator.userAgent)&&!("MSStream"in window),this.FIREFOX=this.isBrowser&&/(firefox|minefield)/i.test(navigator.userAgent),this.ANDROID=this.isBrowser&&/android/i.test(navigator.userAgent)&&!this.TRIDENT,this.SAFARI=this.isBrowser&&/safari/i.test(navigator.userAgent)&&this.WEBKIT}};e.\u0275fac=function(i){return new(i||e)(X(bn))},e.\u0275prov=_({token:e,factory:e.\u0275fac,providedIn:"root"});let t=e;return t})(),Fn=(()=>{let e=class e{};e.\u0275fac=function(i){return new(i||e)},e.\u0275mod=O({type:e}),e.\u0275inj=I({});let t=e;return t})();var Ie=class{constructor(e,a){this._document=a;let n=this._textarea=this._document.createElement("textarea"),i=n.style;i.position="fixed",i.top=i.opacity="0",i.left="-999em",n.setAttribute("aria-hidden","true"),n.value=e,n.readOnly=!0,(this._document.fullscreenElement||this._document.body).appendChild(n)}copy(){let e=this._textarea,a=!1;try{if(e){let n=this._document.activeElement;e.select(),e.setSelectionRange(0,e.value.length),a=this._document.execCommand("copy"),n&&n.focus()}}catch{}return a}destroy(){let e=this._textarea;e&&(e.remove(),this._textarea=void 0)}},jn=(()=>{let e=class e{constructor(n){this._document=n}copy(n){let i=this.beginCopy(n),r=i.copy();return i.destroy(),r}beginCopy(n){return new Ie(n,this._document)}};e.\u0275fac=function(i){return new(i||e)(X(_t))},e.\u0275prov=_({token:e,factory:e.\u0275fac,providedIn:"root"});let t=e;return t})();var Ln=(()=>{let e=class e{};e.\u0275fac=function(i){return new(i||e)},e.\u0275mod=O({type:e}),e.\u0275inj=I({});let t=e;return t})();var mt=new gn("shareButtonsConfig");var Kt=function(t){return t.Anchor="anchor",t.Window="window",t}(Kt||{});function Oe(t){return t&&typeof t=="object"&&!Array.isArray(t)}function Se(t,...e){if(!e.length)return t;let a=e.shift();if(Oe(t)&&Oe(a))for(let n in a)Oe(a[n])?(t[n]||Object.assign(t,{[n]:{}}),Se(t[n],a[n])):Object.assign(t,{[n]:a[n]});return Se(t,...e)}function Qi(t,e){if(t){if(/(http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/.test(t))return t;console.warn(`[ShareButtons]: Sharing link '${t}' is invalid!`)}return e}function Ji(){return new be(t=>document.defaultView.print())}function ta({params:t,data:e,clipboard:a,updater:n}){return zt(null).pipe($t(()=>{a.copy(t.url),n.next({icon:e.successIcon,text:e.successText,disabled:!0})}),mn(e.delay),$t(()=>n.next({icon:e.icon,text:e.text,disabled:!1})),dn(1))}var Xt={description:t=>t.description?`${t.description}\r
${t.url}`:t.url},qt={facebook:{type:"facebook",text:"Facebook",ariaLabel:"Share on Facebook",icon:["fab","facebook-f"],color:"#4267B2",share:{desktop:"https://www.facebook.com/sharer/sharer.php?"},params:{url:"u"}},twitter:{type:"twitter",text:"Twitter",ariaLabel:"Share on Twitter",icon:["fab","twitter"],color:"#00acee",share:{desktop:"https://twitter.com/intent/tweet?"},params:{url:"url",description:"text",tags:"hashtags",via:"via"}},linkedin:{type:"linkedin",text:"LinkedIn",ariaLabel:"Share on LinkedIn",icon:["fab","linkedin-in"],color:"#006fa6",share:{desktop:"https://www.linkedin.com/shareArticle?"},params:{url:"url",title:"title",description:"summary"}},pinterest:{type:"pinterest",text:"Pinterest",ariaLabel:"Share on Pinterest",icon:["fab","pinterest-p"],color:"#BD091D",share:{desktop:"https://pinterest.com/pin/create/button/?"},params:{url:"url",description:"description",image:"media"}},reddit:{type:"reddit",text:"Reddit",ariaLabel:"Share on Reddit",icon:["fab","reddit-alien"],color:"#FF4006",share:{desktop:"https://www.reddit.com/submit?"},params:{url:"url",title:"title"}},tumblr:{type:"tumblr",text:"Tumblr",ariaLabel:"Share on Tumblr",icon:["fab","tumblr"],color:"#36465D",share:{desktop:"https://tumblr.com/widgets/share/tool?"},params:{url:"canonicalUrl",description:"caption",tags:"tags"}},mix:{type:"mix",text:"Mix",ariaLabel:"Share on Mix",icon:["fab","mix"],color:"#eb4924",share:{desktop:"https://mix.com/add?"},params:{url:"url"}},viber:{type:"viber",text:"Viber",ariaLabel:"Share on Viber",icon:["fab","viber"],color:"#665ca7",share:{android:"viber://forward?",ios:"viber://forward?"},params:{description:"text"},paramsFunc:Xt},vk:{type:"vk",text:"VKontakte",ariaLabel:"Share on VKontakte",icon:["fab","vk"],color:"#4C75A3",share:{desktop:"https://vk.com/share.php?"},params:{url:"url"}},telegram:{type:"telegram",text:"Telegram",ariaLabel:"Share on Telegram",icon:["fab","telegram-plane"],color:"#0088cc",share:{desktop:"https://t.me/share/url?"},params:{url:"url",description:"text"}},messenger:{type:"messenger",text:"Messenger",ariaLabel:"Share on Messenger",icon:["fab","facebook-messenger"],color:"#0080FF",share:{desktop:"https://www.facebook.com/dialog/send?",android:"fb-messenger://share/?",ios:"fb-messenger://share/?"},params:{url:"link",appId:"app_id",redirectUrl:"redirect_uri"}},whatsapp:{type:"whatsapp",text:"WhatsApp",ariaLabel:"Share on WhatsApp",icon:["fab","whatsapp"],color:"#25D366",share:{desktop:"https://api.whatsapp.com/send?",android:"whatsapp://send?",ios:"https://api.whatsapp.com/send?"},params:{url:"link",description:"text"},paramsFunc:Xt},xing:{type:"xing",text:"Xing",ariaLabel:"Share on Xing",icon:["fab","xing"],color:"#006567",share:{desktop:"https://www.xing.com/spi/shares/new?"},params:{url:"url"}},line:{type:"line",text:"Line",ariaLabel:"Share on Line",icon:["fab","line"],color:"#00b900",share:{desktop:"https://social-plugins.line.me/lineit/share?"},params:{url:"url"}},sms:{type:"sms",text:"SMS",ariaLabel:"Share link via SMS",icon:["fas","sms"],color:"#20c16c",share:{desktop:"sms:?",ios:"sms:&"},params:{description:"body"},paramsFunc:Xt},email:{type:"email",text:"Email",ariaLabel:"Share link via email",icon:["fas","envelope"],color:"#FF961C",share:{desktop:"mailto:?"},params:{title:"subject",description:"body"},paramsFunc:Xt},print:{type:"print",text:"Print",ariaLabel:"Print page",icon:["fas","print"],color:"#765AA2",func:Ji},copy:{type:"copy",text:"Copy link",ariaLabel:"Copy link",icon:["fas","link"],color:"#607D8B",data:{text:"Copy link",icon:["fas","link"],successText:"Copied",successIcon:["fas","check"],delay:2e3},func:ta}},It=(()=>{let e=class e{constructor(n,i){this._document=i,this.config={sharerMethod:Kt.Anchor,sharerTarget:"_blank",windowObj:this._document.defaultView,windowFuncName:"open",prop:qt,theme:"default",include:[],exclude:[],autoSetMeta:!0,windowWidth:800,windowHeight:500,moreButtonIcon:"ellipsis-h",lessButtonIcon:"minus",moreButtonAriaLabel:"Show more share buttons",lessButtonAriaLabel:"Show less share buttons"},this.config$=new Rt(this.config),n&&this.setConfig(n)}get prop(){return this.config.prop}get windowSize(){return`width=${this.config.windowWidth}, height=${this.config.windowHeight}`}setConfig(n){this.config=Se(this.config,n),this.config$.next(this.config)}addButton(n,i){this.setConfig({prop:{[n]:i}})}};e.\u0275fac=function(i){return new(i||e)(X(mt,8),X(_t))},e.\u0275prov=_({token:e,factory:e.\u0275fac,providedIn:"root"});let t=e;return t})(),Bn=(()=>{let e=class e{constructor(n,i,r,o,s,c,f){this._meta=i,this._platform=r,this._clipboard=o,this._share=s,this._cd=c,this._document=f,this._destroyed=new lt,this._updater=new lt,this.autoSetMeta=this._share.config.autoSetMeta,this.url=this._share.config.url,this.title=this._share.config.title,this.description=this._share.config.description,this.image=this._share.config.image,this.tags=this._share.config.tags,this.redirectUrl=this._share.config.redirectUrl,this.opened=new L,this.closed=new L,this._el=n.nativeElement}share(){if(this._platform.isBrowser&&this.shareButton){let n=this.autoSetMeta?this.getParamsFromMetaTags():this.getParamsFromInputs();(this.shareButton.share?this.open(n):this.shareButton.func({params:n,data:this.shareButton.data,clipboard:this._clipboard,updater:this._updater})).pipe(ye(this._destroyed)).subscribe()}else console.warn(`${this.text} button is not compatible on this Platform`)}ngOnInit(){this._updater.pipe($t(n=>{this.icon=n.icon,this.text=n.text,this._el.style.pointerEvents=n.disabled?"none":"auto",this._cd.markForCheck()}),ye(this._destroyed)).subscribe()}ngOnChanges(n){this._platform.isBrowser&&(this._shareButtonChanged(n.shareButtonName)&&this._createShareButton(),this._urlChanged(n.url)&&(this.url=Qi(this.autoSetMeta?this.url||this._getMetaTagContent("og:url"):this.url,this._document.defaultView.location.href)))}ngOnDestroy(){this._destroyed.next(),this._destroyed.complete()}_createShareButton(){let n=this._share.config.prop[this.shareButtonName];n?(this.shareButton=n,this._el.classList.remove(`sb-${this._buttonClass}`),this._el.classList.add(`sb-${this.shareButtonName}`),this._el.style.setProperty("--button-color",this.shareButton.color),this._buttonClass=this.shareButtonName,this.color=this.shareButton.color,this.text=this.shareButton.text,this.icon=this.shareButton.icon,this._el.setAttribute("aria-label",n.ariaLabel)):console.error(`[ShareButtons]: The share button '${this.shareButtonName}' does not exist!`)}_getMetaTagContent(n){let i=this._meta.getTag(`property="${n}"`);if(i)return i.getAttribute("content");let r=this._meta.getTag(`name="${n}"`);if(r)return r.getAttribute("content")}_shareButtonChanged(n){return n&&(n.firstChange||n.previousValue!==n.currentValue)}_urlChanged(n){return!this.url||n&&n.previousValue!==n.currentValue}getParamsFromMetaTags(){return{url:this.url,title:this.title||this._getMetaTagContent("og:title"),description:this.description||this._getMetaTagContent("og:description"),image:this.image||this._getMetaTagContent("og:image"),via:this._share.config.twitterAccount,tags:this.tags,appId:this._share.config.appId||this._getMetaTagContent("fb:app_id"),redirectUrl:this.redirectUrl||this.url}}getParamsFromInputs(){return{url:this.url,title:this.title,description:this.description,image:this.image,tags:this.tags,via:this._share.config.twitterAccount,appId:this._share.config.appId,redirectUrl:this.redirectUrl||this.url}}open(n){let i;if(this._platform.IOS&&this.shareButton.share.ios?i=this.shareButton.share.ios:this._platform.ANDROID&&this.shareButton.share.android?i=this.shareButton.share.android:i=this.shareButton.share.desktop,i){this._finalUrl=i+this._serializeParams(n),this._share.config.debug&&console.log("[DEBUG SHARE BUTTON]: ",this._finalUrl);let r=this.shareButton.method||this._share.config.sharerMethod,o=this.shareButton.target||this._share.config.sharerTarget;switch(r){case Kt.Anchor:let s=this._document.createElement("a");s.setAttribute("target",o),s.setAttribute("rel","noopener noreferrer"),s.href=this._finalUrl,s.click(),s.remove();break;case Kt.Window:let c=this._share.config.windowObj[this._share.config.windowFuncName],f=c(this._finalUrl,o,this._share.windowSize);if(this._share.config.windowObj.opener=null,f)return new be(l=>{let m=this._document.defaultView.setInterval(()=>{f.closed&&(this._document.defaultView.clearInterval(m),this.closed.emit(this.shareButtonName),l.next(),l.complete())},200)});break}this.opened.emit(this.shareButtonName)}return sn}_serializeParams(n){return Object.entries(this.shareButton.params).map(([i,r])=>{let o=this.shareButton.paramsFunc?this.shareButton.paramsFunc[i]:null;if(n[i]||o){let s=o?o(n):n[i];return`${r}=${encodeURIComponent(s)}`}return""}).filter(i=>i!=="").join("&")}};e.\u0275fac=function(i){return new(i||e)(g(at),g(Tn),g(Dn),g(jn),g(It),g(Vt),g(_t))},e.\u0275dir=ft({type:e,selectors:[["","shareButton",""]],hostBindings:function(i,r){i&1&&U("click",function(){return r.share()})},inputs:{shareButtonName:[we.None,"shareButton","shareButtonName"],autoSetMeta:"autoSetMeta",url:"url",title:"title",description:"description",image:"image",tags:"tags",redirectUrl:"redirectUrl"},outputs:{opened:"opened",closed:"closed"},exportAs:["shareButton"],features:[$]});let t=e;return t})(),Me=(()=>{let e=class e{static withConfig(n){return{ngModule:e,providers:[{provide:mt,useValue:n}]}}};e.\u0275fac=function(i){return new(i||e)},e.\u0275mod=O({type:e}),e.\u0275inj=I({imports:[Fn,Ln]});let t=e;return t})();function zn(t,e){var a=Object.keys(t);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(t);e&&(n=n.filter(function(i){return Object.getOwnPropertyDescriptor(t,i).enumerable})),a.push.apply(a,n)}return a}function u(t){for(var e=1;e<arguments.length;e++){var a=arguments[e]!=null?arguments[e]:{};e%2?zn(Object(a),!0).forEach(function(n){w(t,n,a[n])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(a)):zn(Object(a)).forEach(function(n){Object.defineProperty(t,n,Object.getOwnPropertyDescriptor(a,n))})}return t}function ce(t){"@babel/helpers - typeof";return ce=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(e){return typeof e}:function(e){return e&&typeof Symbol=="function"&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},ce(t)}function ea(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function $n(t,e){for(var a=0;a<e.length;a++){var n=e[a];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}function na(t,e,a){return e&&$n(t.prototype,e),a&&$n(t,a),Object.defineProperty(t,"prototype",{writable:!1}),t}function w(t,e,a){return e in t?Object.defineProperty(t,e,{value:a,enumerable:!0,configurable:!0,writable:!0}):t[e]=a,t}function We(t,e){return aa(t)||oa(t,e)||di(t,e)||ca()}function Dt(t){return ia(t)||ra(t)||di(t)||sa()}function ia(t){if(Array.isArray(t))return Ne(t)}function aa(t){if(Array.isArray(t))return t}function ra(t){if(typeof Symbol<"u"&&t[Symbol.iterator]!=null||t["@@iterator"]!=null)return Array.from(t)}function oa(t,e){var a=t==null?null:typeof Symbol<"u"&&t[Symbol.iterator]||t["@@iterator"];if(a!=null){var n=[],i=!0,r=!1,o,s;try{for(a=a.call(t);!(i=(o=a.next()).done)&&(n.push(o.value),!(e&&n.length===e));i=!0);}catch(c){r=!0,s=c}finally{try{!i&&a.return!=null&&a.return()}finally{if(r)throw s}}return n}}function di(t,e){if(t){if(typeof t=="string")return Ne(t,e);var a=Object.prototype.toString.call(t).slice(8,-1);if(a==="Object"&&t.constructor&&(a=t.constructor.name),a==="Map"||a==="Set")return Array.from(t);if(a==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a))return Ne(t,e)}}function Ne(t,e){(e==null||e>t.length)&&(e=t.length);for(var a=0,n=new Array(e);a<e;a++)n[a]=t[a];return n}function sa(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function ca(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var Un=function(){},Ve={},mi={},hi=null,pi={mark:Un,measure:Un};try{typeof window<"u"&&(Ve=window),typeof document<"u"&&(mi=document),typeof MutationObserver<"u"&&(hi=MutationObserver),typeof performance<"u"&&(pi=performance)}catch{}var la=Ve.navigator||{},Hn=la.userAgent,Wn=Hn===void 0?"":Hn,Z=Ve,b=mi,Vn=hi,Zt=pi,Oo=!!Z.document,Y=!!b.documentElement&&!!b.head&&typeof b.addEventListener=="function"&&typeof b.createElement=="function",gi=~Wn.indexOf("MSIE")||~Wn.indexOf("Trident/"),Qt,Jt,te,ee,ne,H="___FONT_AWESOME___",De=16,vi="fa",bi="svg-inline--fa",st="data-fa-i2svg",Fe="data-fa-pseudo-element",fa="data-fa-pseudo-element-pending",Ye="data-prefix",Ge="data-icon",Yn="fontawesome-i2svg",ua="async",da=["HTML","HEAD","STYLE","SCRIPT"],yi=function(){try{return!0}catch{return!1}}(),v="classic",y="sharp",Xe=[v,y];function Ft(t){return new Proxy(t,{get:function(a,n){return n in a?a[n]:a[v]}})}var Pt=Ft((Qt={},w(Qt,v,{fa:"solid",fas:"solid","fa-solid":"solid",far:"regular","fa-regular":"regular",fal:"light","fa-light":"light",fat:"thin","fa-thin":"thin",fad:"duotone","fa-duotone":"duotone",fab:"brands","fa-brands":"brands",fak:"kit",fakd:"kit","fa-kit":"kit","fa-kit-duotone":"kit"}),w(Qt,y,{fa:"solid",fass:"solid","fa-solid":"solid",fasr:"regular","fa-regular":"regular",fasl:"light","fa-light":"light",fast:"thin","fa-thin":"thin"}),Qt)),At=Ft((Jt={},w(Jt,v,{solid:"fas",regular:"far",light:"fal",thin:"fat",duotone:"fad",brands:"fab",kit:"fak"}),w(Jt,y,{solid:"fass",regular:"fasr",light:"fasl",thin:"fast"}),Jt)),Et=Ft((te={},w(te,v,{fab:"fa-brands",fad:"fa-duotone",fak:"fa-kit",fal:"fa-light",far:"fa-regular",fas:"fa-solid",fat:"fa-thin"}),w(te,y,{fass:"fa-solid",fasr:"fa-regular",fasl:"fa-light",fast:"fa-thin"}),te)),ma=Ft((ee={},w(ee,v,{"fa-brands":"fab","fa-duotone":"fad","fa-kit":"fak","fa-light":"fal","fa-regular":"far","fa-solid":"fas","fa-thin":"fat"}),w(ee,y,{"fa-solid":"fass","fa-regular":"fasr","fa-light":"fasl","fa-thin":"fast"}),ee)),ha=/fa(s|r|l|t|d|b|k|ss|sr|sl|st)?[\-\ ]/,wi="fa-layers-text",pa=/Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp|Kit)?.*/i,ga=Ft((ne={},w(ne,v,{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"}),w(ne,y,{900:"fass",400:"fasr",300:"fasl",100:"fast"}),ne)),xi=[1,2,3,4,5,6,7,8,9,10],va=xi.concat([11,12,13,14,15,16,17,18,19,20]),ba=["class","data-prefix","data-icon","data-fa-transform","data-fa-mask"],rt={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},Tt=new Set;Object.keys(At[v]).map(Tt.add.bind(Tt));Object.keys(At[y]).map(Tt.add.bind(Tt));var ya=[].concat(Xe,Dt(Tt),["2xs","xs","sm","lg","xl","2xl","beat","border","fade","beat-fade","bounce","flip-both","flip-horizontal","flip-vertical","flip","fw","inverse","layers-counter","layers-text","layers","li","pull-left","pull-right","pulse","rotate-180","rotate-270","rotate-90","rotate-by","shake","spin-pulse","spin-reverse","spin","stack-1x","stack-2x","stack","ul",rt.GROUP,rt.SWAP_OPACITY,rt.PRIMARY,rt.SECONDARY]).concat(xi.map(function(t){return"".concat(t,"x")})).concat(va.map(function(t){return"w-".concat(t)})),St=Z.FontAwesomeConfig||{};function wa(t){var e=b.querySelector("script["+t+"]");if(e)return e.getAttribute(t)}function xa(t){return t===""?!0:t==="false"?!1:t==="true"?!0:t}b&&typeof b.querySelector=="function"&&(Gn=[["data-family-prefix","familyPrefix"],["data-css-prefix","cssPrefix"],["data-family-default","familyDefault"],["data-style-default","styleDefault"],["data-replacement-class","replacementClass"],["data-auto-replace-svg","autoReplaceSvg"],["data-auto-add-css","autoAddCss"],["data-auto-a11y","autoA11y"],["data-search-pseudo-elements","searchPseudoElements"],["data-observe-mutations","observeMutations"],["data-mutate-approach","mutateApproach"],["data-keep-original-source","keepOriginalSource"],["data-measure-performance","measurePerformance"],["data-show-missing-icons","showMissingIcons"]],Gn.forEach(function(t){var e=We(t,2),a=e[0],n=e[1],i=xa(wa(a));i!=null&&(St[n]=i)}));var Gn,ki={styleDefault:"solid",familyDefault:"classic",cssPrefix:vi,replacementClass:bi,autoReplaceSvg:!0,autoAddCss:!0,autoA11y:!0,searchPseudoElements:!1,observeMutations:!0,mutateApproach:"async",keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};St.familyPrefix&&(St.cssPrefix=St.familyPrefix);var vt=u(u({},ki),St);vt.autoReplaceSvg||(vt.observeMutations=!1);var d={};Object.keys(ki).forEach(function(t){Object.defineProperty(d,t,{enumerable:!0,set:function(a){vt[t]=a,Mt.forEach(function(n){return n(d)})},get:function(){return vt[t]}})});Object.defineProperty(d,"familyPrefix",{enumerable:!0,set:function(e){vt.cssPrefix=e,Mt.forEach(function(a){return a(d)})},get:function(){return vt.cssPrefix}});Z.FontAwesomeConfig=d;var Mt=[];function ka(t){return Mt.push(t),function(){Mt.splice(Mt.indexOf(t),1)}}var q=De,z={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function Ca(t){if(!(!t||!Y)){var e=b.createElement("style");e.setAttribute("type","text/css"),e.innerHTML=t;for(var a=b.head.childNodes,n=null,i=a.length-1;i>-1;i--){var r=a[i],o=(r.tagName||"").toUpperCase();["STYLE","LINK"].indexOf(o)>-1&&(n=r)}return b.head.insertBefore(e,n),t}}var _a="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function Nt(){for(var t=12,e="";t-- >0;)e+=_a[Math.random()*62|0];return e}function bt(t){for(var e=[],a=(t||[]).length>>>0;a--;)e[a]=t[a];return e}function Ke(t){return t.classList?bt(t.classList):(t.getAttribute("class")||"").split(" ").filter(function(e){return e})}function Ci(t){return"".concat(t).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Ia(t){return Object.keys(t||{}).reduce(function(e,a){return e+"".concat(a,'="').concat(Ci(t[a]),'" ')},"").trim()}function ue(t){return Object.keys(t||{}).reduce(function(e,a){return e+"".concat(a,": ").concat(t[a].trim(),";")},"")}function qe(t){return t.size!==z.size||t.x!==z.x||t.y!==z.y||t.rotate!==z.rotate||t.flipX||t.flipY}function Oa(t){var e=t.transform,a=t.containerWidth,n=t.iconWidth,i={transform:"translate(".concat(a/2," 256)")},r="translate(".concat(e.x*32,", ").concat(e.y*32,") "),o="scale(".concat(e.size/16*(e.flipX?-1:1),", ").concat(e.size/16*(e.flipY?-1:1),") "),s="rotate(".concat(e.rotate," 0 0)"),c={transform:"".concat(r," ").concat(o," ").concat(s)},f={transform:"translate(".concat(n/2*-1," -256)")};return{outer:i,inner:c,path:f}}function Sa(t){var e=t.transform,a=t.width,n=a===void 0?De:a,i=t.height,r=i===void 0?De:i,o=t.startCentered,s=o===void 0?!1:o,c="";return s&&gi?c+="translate(".concat(e.x/q-n/2,"em, ").concat(e.y/q-r/2,"em) "):s?c+="translate(calc(-50% + ".concat(e.x/q,"em), calc(-50% + ").concat(e.y/q,"em)) "):c+="translate(".concat(e.x/q,"em, ").concat(e.y/q,"em) "),c+="scale(".concat(e.size/q*(e.flipX?-1:1),", ").concat(e.size/q*(e.flipY?-1:1),") "),c+="rotate(".concat(e.rotate,"deg) "),c}var Ma=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Solid";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Regular";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Light";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Thin";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-counter-scale, 0.25));
          transform: scale(var(--fa-counter-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom right;
          transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom left;
          transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top left;
          transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(var(--fa-li-width, 2em) * -1);
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  -webkit-animation-name: fa-beat;
          animation-name: fa-beat;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  -webkit-animation-name: fa-bounce;
          animation-name: fa-bounce;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  -webkit-animation-name: fa-fade;
          animation-name: fa-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  -webkit-animation-name: fa-beat-fade;
          animation-name: fa-beat-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  -webkit-animation-name: fa-flip;
          animation-name: fa-flip;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  -webkit-animation-name: fa-shake;
          animation-name: fa-shake;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 2s);
          animation-duration: var(--fa-animation-duration, 2s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, steps(8));
          animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    -webkit-animation-delay: -1ms;
            animation-delay: -1ms;
    -webkit-animation-duration: 1ms;
            animation-duration: 1ms;
    -webkit-animation-iteration-count: 1;
            animation-iteration-count: 1;
    -webkit-transition-delay: 0s;
            transition-delay: 0s;
    -webkit-transition-duration: 0s;
            transition-duration: 0s;
  }
}
@-webkit-keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@-webkit-keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@-webkit-keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@-webkit-keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@-webkit-keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@-webkit-keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@-webkit-keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
@keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  -webkit-transform: rotate(90deg);
          transform: rotate(90deg);
}

.fa-rotate-180 {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg);
}

.fa-rotate-270 {
  -webkit-transform: rotate(270deg);
          transform: rotate(270deg);
}

.fa-flip-horizontal {
  -webkit-transform: scale(-1, 1);
          transform: scale(-1, 1);
}

.fa-flip-vertical {
  -webkit-transform: scale(1, -1);
          transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  -webkit-transform: scale(-1, -1);
          transform: scale(-1, -1);
}

.fa-rotate-by {
  -webkit-transform: rotate(var(--fa-rotate-angle, none));
          transform: rotate(var(--fa-rotate-angle, none));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}`;function _i(){var t=vi,e=bi,a=d.cssPrefix,n=d.replacementClass,i=Ma;if(a!==t||n!==e){var r=new RegExp("\\.".concat(t,"\\-"),"g"),o=new RegExp("\\--".concat(t,"\\-"),"g"),s=new RegExp("\\.".concat(e),"g");i=i.replace(r,".".concat(a,"-")).replace(o,"--".concat(a,"-")).replace(s,".".concat(n))}return i}var Xn=!1;function Pe(){d.autoAddCss&&!Xn&&(Ca(_i()),Xn=!0)}var Pa={mixout:function(){return{dom:{css:_i,insertCss:Pe}}},hooks:function(){return{beforeDOMElementCreation:function(){Pe()},beforeI2svg:function(){Pe()}}}},W=Z||{};W[H]||(W[H]={});W[H].styles||(W[H].styles={});W[H].hooks||(W[H].hooks={});W[H].shims||(W[H].shims=[]);var D=W[H],Ii=[],Aa=function t(){b.removeEventListener("DOMContentLoaded",t),le=1,Ii.map(function(e){return e()})},le=!1;Y&&(le=(b.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(b.readyState),le||b.addEventListener("DOMContentLoaded",Aa));function Ea(t){Y&&(le?setTimeout(t,0):Ii.push(t))}function jt(t){var e=t.tag,a=t.attributes,n=a===void 0?{}:a,i=t.children,r=i===void 0?[]:i;return typeof t=="string"?Ci(t):"<".concat(e," ").concat(Ia(n),">").concat(r.map(jt).join(""),"</").concat(e,">")}function Kn(t,e,a){if(t&&t[e]&&t[e][a])return{prefix:e,iconName:a,icon:t[e][a]}}var Ta=function(e,a){return function(n,i,r,o){return e.call(a,n,i,r,o)}},Ae=function(e,a,n,i){var r=Object.keys(e),o=r.length,s=i!==void 0?Ta(a,i):a,c,f,l;for(n===void 0?(c=1,l=e[r[0]]):(c=0,l=n);c<o;c++)f=r[c],l=s(l,e[f],f,e);return l};function Na(t){for(var e=[],a=0,n=t.length;a<n;){var i=t.charCodeAt(a++);if(i>=55296&&i<=56319&&a<n){var r=t.charCodeAt(a++);(r&64512)==56320?e.push(((i&1023)<<10)+(r&1023)+65536):(e.push(i),a--)}else e.push(i)}return e}function je(t){var e=Na(t);return e.length===1?e[0].toString(16):null}function Da(t,e){var a=t.length,n=t.charCodeAt(e),i;return n>=55296&&n<=56319&&a>e+1&&(i=t.charCodeAt(e+1),i>=56320&&i<=57343)?(n-55296)*1024+i-56320+65536:n}function qn(t){return Object.keys(t).reduce(function(e,a){var n=t[a],i=!!n.icon;return i?e[n.iconName]=n.icon:e[a]=n,e},{})}function Le(t,e){var a=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},n=a.skipHooks,i=n===void 0?!1:n,r=qn(e);typeof D.hooks.addPack=="function"&&!i?D.hooks.addPack(t,qn(e)):D.styles[t]=u(u({},D.styles[t]||{}),r),t==="fas"&&Le("fa",e)}var ie,ae,re,ht=D.styles,Fa=D.shims,ja=(ie={},w(ie,v,Object.values(Et[v])),w(ie,y,Object.values(Et[y])),ie),Ze=null,Oi={},Si={},Mi={},Pi={},Ai={},La=(ae={},w(ae,v,Object.keys(Pt[v])),w(ae,y,Object.keys(Pt[y])),ae);function Ba(t){return~ya.indexOf(t)}function Ra(t,e){var a=e.split("-"),n=a[0],i=a.slice(1).join("-");return n===t&&i!==""&&!Ba(i)?i:null}var Ei=function(){var e=function(r){return Ae(ht,function(o,s,c){return o[c]=Ae(s,r,{}),o},{})};Oi=e(function(i,r,o){if(r[3]&&(i[r[3]]=o),r[2]){var s=r[2].filter(function(c){return typeof c=="number"});s.forEach(function(c){i[c.toString(16)]=o})}return i}),Si=e(function(i,r,o){if(i[o]=o,r[2]){var s=r[2].filter(function(c){return typeof c=="string"});s.forEach(function(c){i[c]=o})}return i}),Ai=e(function(i,r,o){var s=r[2];return i[o]=o,s.forEach(function(c){i[c]=o}),i});var a="far"in ht||d.autoFetchSvg,n=Ae(Fa,function(i,r){var o=r[0],s=r[1],c=r[2];return s==="far"&&!a&&(s="fas"),typeof o=="string"&&(i.names[o]={prefix:s,iconName:c}),typeof o=="number"&&(i.unicodes[o.toString(16)]={prefix:s,iconName:c}),i},{names:{},unicodes:{}});Mi=n.names,Pi=n.unicodes,Ze=de(d.styleDefault,{family:d.familyDefault})};ka(function(t){Ze=de(t.styleDefault,{family:d.familyDefault})});Ei();function Qe(t,e){return(Oi[t]||{})[e]}function za(t,e){return(Si[t]||{})[e]}function ot(t,e){return(Ai[t]||{})[e]}function Ti(t){return Mi[t]||{prefix:null,iconName:null}}function $a(t){var e=Pi[t],a=Qe("fas",t);return e||(a?{prefix:"fas",iconName:a}:null)||{prefix:null,iconName:null}}function Q(){return Ze}var Je=function(){return{prefix:null,iconName:null,rest:[]}};function de(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=e.family,n=a===void 0?v:a,i=Pt[n][t],r=At[n][t]||At[n][i],o=t in D.styles?t:null;return r||o||null}var Zn=(re={},w(re,v,Object.keys(Et[v])),w(re,y,Object.keys(Et[y])),re);function me(t){var e,a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=a.skipLookups,i=n===void 0?!1:n,r=(e={},w(e,v,"".concat(d.cssPrefix,"-").concat(v)),w(e,y,"".concat(d.cssPrefix,"-").concat(y)),e),o=null,s=v;(t.includes(r[v])||t.some(function(f){return Zn[v].includes(f)}))&&(s=v),(t.includes(r[y])||t.some(function(f){return Zn[y].includes(f)}))&&(s=y);var c=t.reduce(function(f,l){var m=Ra(d.cssPrefix,l);if(ht[l]?(l=ja[s].includes(l)?ma[s][l]:l,o=l,f.prefix=l):La[s].indexOf(l)>-1?(o=l,f.prefix=de(l,{family:s})):m?f.iconName=m:l!==d.replacementClass&&l!==r[v]&&l!==r[y]&&f.rest.push(l),!i&&f.prefix&&f.iconName){var h=o==="fa"?Ti(f.iconName):{},p=ot(f.prefix,f.iconName);h.prefix&&(o=null),f.iconName=h.iconName||p||f.iconName,f.prefix=h.prefix||f.prefix,f.prefix==="far"&&!ht.far&&ht.fas&&!d.autoFetchSvg&&(f.prefix="fas")}return f},Je());return(t.includes("fa-brands")||t.includes("fab"))&&(c.prefix="fab"),(t.includes("fa-duotone")||t.includes("fad"))&&(c.prefix="fad"),!c.prefix&&s===y&&(ht.fass||d.autoFetchSvg)&&(c.prefix="fass",c.iconName=ot(c.prefix,c.iconName)||c.iconName),(c.prefix==="fa"||o==="fa")&&(c.prefix=Q()||"fas"),c}var Ua=function(){function t(){ea(this,t),this.definitions={}}return na(t,[{key:"add",value:function(){for(var a=this,n=arguments.length,i=new Array(n),r=0;r<n;r++)i[r]=arguments[r];var o=i.reduce(this._pullDefinitions,{});Object.keys(o).forEach(function(s){a.definitions[s]=u(u({},a.definitions[s]||{}),o[s]),Le(s,o[s]);var c=Et[v][s];c&&Le(c,o[s]),Ei()})}},{key:"reset",value:function(){this.definitions={}}},{key:"_pullDefinitions",value:function(a,n){var i=n.prefix&&n.iconName&&n.icon?{0:n}:n;return Object.keys(i).map(function(r){var o=i[r],s=o.prefix,c=o.iconName,f=o.icon,l=f[2];a[s]||(a[s]={}),l.length>0&&l.forEach(function(m){typeof m=="string"&&(a[s][m]=f)}),a[s][c]=f}),a}}]),t}(),Qn=[],pt={},gt={},Ha=Object.keys(gt);function Wa(t,e){var a=e.mixoutsTo;return Qn=t,pt={},Object.keys(gt).forEach(function(n){Ha.indexOf(n)===-1&&delete gt[n]}),Qn.forEach(function(n){var i=n.mixout?n.mixout():{};if(Object.keys(i).forEach(function(o){typeof i[o]=="function"&&(a[o]=i[o]),ce(i[o])==="object"&&Object.keys(i[o]).forEach(function(s){a[o]||(a[o]={}),a[o][s]=i[o][s]})}),n.hooks){var r=n.hooks();Object.keys(r).forEach(function(o){pt[o]||(pt[o]=[]),pt[o].push(r[o])})}n.provides&&n.provides(gt)}),a}function Be(t,e){for(var a=arguments.length,n=new Array(a>2?a-2:0),i=2;i<a;i++)n[i-2]=arguments[i];var r=pt[t]||[];return r.forEach(function(o){e=o.apply(null,[e].concat(n))}),e}function ct(t){for(var e=arguments.length,a=new Array(e>1?e-1:0),n=1;n<e;n++)a[n-1]=arguments[n];var i=pt[t]||[];i.forEach(function(r){r.apply(null,a)})}function V(){var t=arguments[0],e=Array.prototype.slice.call(arguments,1);return gt[t]?gt[t].apply(null,e):void 0}function Re(t){t.prefix==="fa"&&(t.prefix="fas");var e=t.iconName,a=t.prefix||Q();if(e)return e=ot(a,e)||e,Kn(Ni.definitions,a,e)||Kn(D.styles,a,e)}var Ni=new Ua,Va=function(){d.autoReplaceSvg=!1,d.observeMutations=!1,ct("noAuto")},Ya={i2svg:function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return Y?(ct("beforeI2svg",e),V("pseudoElements2svg",e),V("i2svg",e)):Promise.reject("Operation requires a DOM of some kind.")},watch:function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},a=e.autoReplaceSvgRoot;d.autoReplaceSvg===!1&&(d.autoReplaceSvg=!0),d.observeMutations=!0,Ea(function(){Xa({autoReplaceSvgRoot:a}),ct("watch",e)})}},Ga={icon:function(e){if(e===null)return null;if(ce(e)==="object"&&e.prefix&&e.iconName)return{prefix:e.prefix,iconName:ot(e.prefix,e.iconName)||e.iconName};if(Array.isArray(e)&&e.length===2){var a=e[1].indexOf("fa-")===0?e[1].slice(3):e[1],n=de(e[0]);return{prefix:n,iconName:ot(n,a)||a}}if(typeof e=="string"&&(e.indexOf("".concat(d.cssPrefix,"-"))>-1||e.match(ha))){var i=me(e.split(" "),{skipLookups:!0});return{prefix:i.prefix||Q(),iconName:ot(i.prefix,i.iconName)||i.iconName}}if(typeof e=="string"){var r=Q();return{prefix:r,iconName:ot(r,e)||e}}}},P={noAuto:Va,config:d,dom:Ya,parse:Ga,library:Ni,findIconDefinition:Re,toHtml:jt},Xa=function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},a=e.autoReplaceSvgRoot,n=a===void 0?b:a;(Object.keys(D.styles).length>0||d.autoFetchSvg)&&Y&&d.autoReplaceSvg&&P.dom.i2svg({node:n})};function he(t,e){return Object.defineProperty(t,"abstract",{get:e}),Object.defineProperty(t,"html",{get:function(){return t.abstract.map(function(n){return jt(n)})}}),Object.defineProperty(t,"node",{get:function(){if(Y){var n=b.createElement("div");return n.innerHTML=t.html,n.children}}}),t}function Ka(t){var e=t.children,a=t.main,n=t.mask,i=t.attributes,r=t.styles,o=t.transform;if(qe(o)&&a.found&&!n.found){var s=a.width,c=a.height,f={x:s/c/2,y:.5};i.style=ue(u(u({},r),{},{"transform-origin":"".concat(f.x+o.x/16,"em ").concat(f.y+o.y/16,"em")}))}return[{tag:"svg",attributes:i,children:e}]}function qa(t){var e=t.prefix,a=t.iconName,n=t.children,i=t.attributes,r=t.symbol,o=r===!0?"".concat(e,"-").concat(d.cssPrefix,"-").concat(a):r;return[{tag:"svg",attributes:{style:"display: none;"},children:[{tag:"symbol",attributes:u(u({},i),{},{id:o}),children:n}]}]}function tn(t){var e=t.icons,a=e.main,n=e.mask,i=t.prefix,r=t.iconName,o=t.transform,s=t.symbol,c=t.title,f=t.maskId,l=t.titleId,m=t.extra,h=t.watchable,p=h===void 0?!1:h,k=n.found?n:a,A=k.width,T=k.height,F=i==="fak",x=[d.replacementClass,r?"".concat(d.cssPrefix,"-").concat(r):""].filter(function(G){return m.classes.indexOf(G)===-1}).filter(function(G){return G!==""||!!G}).concat(m.classes).join(" "),C={children:[],attributes:u(u({},m.attributes),{},{"data-prefix":i,"data-icon":r,class:x,role:m.attributes.role||"img",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 ".concat(A," ").concat(T)})},j=F&&!~m.classes.indexOf("fa-fw")?{width:"".concat(A/T*16*.0625,"em")}:{};p&&(C.attributes[st]=""),c&&(C.children.push({tag:"title",attributes:{id:C.attributes["aria-labelledby"]||"title-".concat(l||Nt())},children:[c]}),delete C.attributes.title);var S=u(u({},C),{},{prefix:i,iconName:r,main:a,mask:n,maskId:f,transform:o,symbol:s,styles:u(u({},j),m.styles)}),tt=n.found&&a.found?V("generateAbstractMask",S)||{children:[],attributes:{}}:V("generateAbstractIcon",S)||{children:[],attributes:{}},et=tt.children,ge=tt.attributes;return S.children=et,S.attributes=ge,s?qa(S):Ka(S)}function Jn(t){var e=t.content,a=t.width,n=t.height,i=t.transform,r=t.title,o=t.extra,s=t.watchable,c=s===void 0?!1:s,f=u(u(u({},o.attributes),r?{title:r}:{}),{},{class:o.classes.join(" ")});c&&(f[st]="");var l=u({},o.styles);qe(i)&&(l.transform=Sa({transform:i,startCentered:!0,width:a,height:n}),l["-webkit-transform"]=l.transform);var m=ue(l);m.length>0&&(f.style=m);var h=[];return h.push({tag:"span",attributes:f,children:[e]}),r&&h.push({tag:"span",attributes:{class:"sr-only"},children:[r]}),h}function Za(t){var e=t.content,a=t.title,n=t.extra,i=u(u(u({},n.attributes),a?{title:a}:{}),{},{class:n.classes.join(" ")}),r=ue(n.styles);r.length>0&&(i.style=r);var o=[];return o.push({tag:"span",attributes:i,children:[e]}),a&&o.push({tag:"span",attributes:{class:"sr-only"},children:[a]}),o}var Ee=D.styles;function ze(t){var e=t[0],a=t[1],n=t.slice(4),i=We(n,1),r=i[0],o=null;return Array.isArray(r)?o={tag:"g",attributes:{class:"".concat(d.cssPrefix,"-").concat(rt.GROUP)},children:[{tag:"path",attributes:{class:"".concat(d.cssPrefix,"-").concat(rt.SECONDARY),fill:"currentColor",d:r[0]}},{tag:"path",attributes:{class:"".concat(d.cssPrefix,"-").concat(rt.PRIMARY),fill:"currentColor",d:r[1]}}]}:o={tag:"path",attributes:{fill:"currentColor",d:r}},{found:!0,width:e,height:a,icon:o}}var Qa={found:!1,width:512,height:512};function Ja(t,e){!yi&&!d.showMissingIcons&&t&&console.error('Icon with name "'.concat(t,'" and prefix "').concat(e,'" is missing.'))}function $e(t,e){var a=e;return e==="fa"&&d.styleDefault!==null&&(e=Q()),new Promise(function(n,i){var r={found:!1,width:512,height:512,icon:V("missingIconAbstract")||{}};if(a==="fa"){var o=Ti(t)||{};t=o.iconName||t,e=o.prefix||e}if(t&&e&&Ee[e]&&Ee[e][t]){var s=Ee[e][t];return n(ze(s))}Ja(t,e),n(u(u({},Qa),{},{icon:d.showMissingIcons&&t?V("missingIconAbstract")||{}:{}}))})}var ti=function(){},Ue=d.measurePerformance&&Zt&&Zt.mark&&Zt.measure?Zt:{mark:ti,measure:ti},Ot='FA "6.5.1"',tr=function(e){return Ue.mark("".concat(Ot," ").concat(e," begins")),function(){return Di(e)}},Di=function(e){Ue.mark("".concat(Ot," ").concat(e," ends")),Ue.measure("".concat(Ot," ").concat(e),"".concat(Ot," ").concat(e," begins"),"".concat(Ot," ").concat(e," ends"))},en={begin:tr,end:Di},oe=function(){};function ei(t){var e=t.getAttribute?t.getAttribute(st):null;return typeof e=="string"}function er(t){var e=t.getAttribute?t.getAttribute(Ye):null,a=t.getAttribute?t.getAttribute(Ge):null;return e&&a}function nr(t){return t&&t.classList&&t.classList.contains&&t.classList.contains(d.replacementClass)}function ir(){if(d.autoReplaceSvg===!0)return se.replace;var t=se[d.autoReplaceSvg];return t||se.replace}function ar(t){return b.createElementNS("http://www.w3.org/2000/svg",t)}function rr(t){return b.createElement(t)}function Fi(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=e.ceFn,n=a===void 0?t.tag==="svg"?ar:rr:a;if(typeof t=="string")return b.createTextNode(t);var i=n(t.tag);Object.keys(t.attributes||[]).forEach(function(o){i.setAttribute(o,t.attributes[o])});var r=t.children||[];return r.forEach(function(o){i.appendChild(Fi(o,{ceFn:n}))}),i}function or(t){var e=" ".concat(t.outerHTML," ");return e="".concat(e,"Font Awesome fontawesome.com "),e}var se={replace:function(e){var a=e[0];if(a.parentNode)if(e[1].forEach(function(i){a.parentNode.insertBefore(Fi(i),a)}),a.getAttribute(st)===null&&d.keepOriginalSource){var n=b.createComment(or(a));a.parentNode.replaceChild(n,a)}else a.remove()},nest:function(e){var a=e[0],n=e[1];if(~Ke(a).indexOf(d.replacementClass))return se.replace(e);var i=new RegExp("".concat(d.cssPrefix,"-.*"));if(delete n[0].attributes.id,n[0].attributes.class){var r=n[0].attributes.class.split(" ").reduce(function(s,c){return c===d.replacementClass||c.match(i)?s.toSvg.push(c):s.toNode.push(c),s},{toNode:[],toSvg:[]});n[0].attributes.class=r.toSvg.join(" "),r.toNode.length===0?a.removeAttribute("class"):a.setAttribute("class",r.toNode.join(" "))}var o=n.map(function(s){return jt(s)}).join(`
`);a.setAttribute(st,""),a.innerHTML=o}};function ni(t){t()}function ji(t,e){var a=typeof e=="function"?e:oe;if(t.length===0)a();else{var n=ni;d.mutateApproach===ua&&(n=Z.requestAnimationFrame||ni),n(function(){var i=ir(),r=en.begin("mutate");t.map(i),r(),a()})}}var nn=!1;function Li(){nn=!0}function He(){nn=!1}var fe=null;function ii(t){if(Vn&&d.observeMutations){var e=t.treeCallback,a=e===void 0?oe:e,n=t.nodeCallback,i=n===void 0?oe:n,r=t.pseudoElementsCallback,o=r===void 0?oe:r,s=t.observeMutationsRoot,c=s===void 0?b:s;fe=new Vn(function(f){if(!nn){var l=Q();bt(f).forEach(function(m){if(m.type==="childList"&&m.addedNodes.length>0&&!ei(m.addedNodes[0])&&(d.searchPseudoElements&&o(m.target),a(m.target)),m.type==="attributes"&&m.target.parentNode&&d.searchPseudoElements&&o(m.target.parentNode),m.type==="attributes"&&ei(m.target)&&~ba.indexOf(m.attributeName))if(m.attributeName==="class"&&er(m.target)){var h=me(Ke(m.target)),p=h.prefix,k=h.iconName;m.target.setAttribute(Ye,p||l),k&&m.target.setAttribute(Ge,k)}else nr(m.target)&&i(m.target)})}}),Y&&fe.observe(c,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}}function sr(){fe&&fe.disconnect()}function cr(t){var e=t.getAttribute("style"),a=[];return e&&(a=e.split(";").reduce(function(n,i){var r=i.split(":"),o=r[0],s=r.slice(1);return o&&s.length>0&&(n[o]=s.join(":").trim()),n},{})),a}function lr(t){var e=t.getAttribute("data-prefix"),a=t.getAttribute("data-icon"),n=t.innerText!==void 0?t.innerText.trim():"",i=me(Ke(t));return i.prefix||(i.prefix=Q()),e&&a&&(i.prefix=e,i.iconName=a),i.iconName&&i.prefix||(i.prefix&&n.length>0&&(i.iconName=za(i.prefix,t.innerText)||Qe(i.prefix,je(t.innerText))),!i.iconName&&d.autoFetchSvg&&t.firstChild&&t.firstChild.nodeType===Node.TEXT_NODE&&(i.iconName=t.firstChild.data)),i}function fr(t){var e=bt(t.attributes).reduce(function(i,r){return i.name!=="class"&&i.name!=="style"&&(i[r.name]=r.value),i},{}),a=t.getAttribute("title"),n=t.getAttribute("data-fa-title-id");return d.autoA11y&&(a?e["aria-labelledby"]="".concat(d.replacementClass,"-title-").concat(n||Nt()):(e["aria-hidden"]="true",e.focusable="false")),e}function ur(){return{iconName:null,title:null,titleId:null,prefix:null,transform:z,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function ai(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0},a=lr(t),n=a.iconName,i=a.prefix,r=a.rest,o=fr(t),s=Be("parseNodeAttributes",{},t),c=e.styleParser?cr(t):[];return u({iconName:n,title:t.getAttribute("title"),titleId:t.getAttribute("data-fa-title-id"),prefix:i,transform:z,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:r,styles:c,attributes:o}},s)}var dr=D.styles;function Bi(t){var e=d.autoReplaceSvg==="nest"?ai(t,{styleParser:!1}):ai(t);return~e.extra.classes.indexOf(wi)?V("generateLayersText",t,e):V("generateSvgReplacementMutation",t,e)}var J=new Set;Xe.map(function(t){J.add("fa-".concat(t))});Object.keys(Pt[v]).map(J.add.bind(J));Object.keys(Pt[y]).map(J.add.bind(J));J=Dt(J);function ri(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!Y)return Promise.resolve();var a=b.documentElement.classList,n=function(m){return a.add("".concat(Yn,"-").concat(m))},i=function(m){return a.remove("".concat(Yn,"-").concat(m))},r=d.autoFetchSvg?J:Xe.map(function(l){return"fa-".concat(l)}).concat(Object.keys(dr));r.includes("fa")||r.push("fa");var o=[".".concat(wi,":not([").concat(st,"])")].concat(r.map(function(l){return".".concat(l,":not([").concat(st,"])")})).join(", ");if(o.length===0)return Promise.resolve();var s=[];try{s=bt(t.querySelectorAll(o))}catch{}if(s.length>0)n("pending"),i("complete");else return Promise.resolve();var c=en.begin("onTree"),f=s.reduce(function(l,m){try{var h=Bi(m);h&&l.push(h)}catch(p){yi||p.name==="MissingIcon"&&console.error(p)}return l},[]);return new Promise(function(l,m){Promise.all(f).then(function(h){ji(h,function(){n("active"),n("complete"),i("pending"),typeof e=="function"&&e(),c(),l()})}).catch(function(h){c(),m(h)})})}function mr(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;Bi(t).then(function(a){a&&ji([a],e)})}function hr(t){return function(e){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=(e||{}).icon?e:Re(e||{}),i=a.mask;return i&&(i=(i||{}).icon?i:Re(i||{})),t(n,u(u({},a),{},{mask:i}))}}var pr=function(e){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=a.transform,i=n===void 0?z:n,r=a.symbol,o=r===void 0?!1:r,s=a.mask,c=s===void 0?null:s,f=a.maskId,l=f===void 0?null:f,m=a.title,h=m===void 0?null:m,p=a.titleId,k=p===void 0?null:p,A=a.classes,T=A===void 0?[]:A,F=a.attributes,x=F===void 0?{}:F,C=a.styles,j=C===void 0?{}:C;if(e){var S=e.prefix,tt=e.iconName,et=e.icon;return he(u({type:"icon"},e),function(){return ct("beforeDOMElementCreation",{iconDefinition:e,params:a}),d.autoA11y&&(h?x["aria-labelledby"]="".concat(d.replacementClass,"-title-").concat(k||Nt()):(x["aria-hidden"]="true",x.focusable="false")),tn({icons:{main:ze(et),mask:c?ze(c.icon):{found:!1,width:null,height:null,icon:{}}},prefix:S,iconName:tt,transform:u(u({},z),i),symbol:o,title:h,maskId:l,titleId:k,extra:{attributes:x,styles:j,classes:T}})})}},gr={mixout:function(){return{icon:hr(pr)}},hooks:function(){return{mutationObserverCallbacks:function(a){return a.treeCallback=ri,a.nodeCallback=mr,a}}},provides:function(e){e.i2svg=function(a){var n=a.node,i=n===void 0?b:n,r=a.callback,o=r===void 0?function(){}:r;return ri(i,o)},e.generateSvgReplacementMutation=function(a,n){var i=n.iconName,r=n.title,o=n.titleId,s=n.prefix,c=n.transform,f=n.symbol,l=n.mask,m=n.maskId,h=n.extra;return new Promise(function(p,k){Promise.all([$e(i,s),l.iconName?$e(l.iconName,l.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(function(A){var T=We(A,2),F=T[0],x=T[1];p([a,tn({icons:{main:F,mask:x},prefix:s,iconName:i,transform:c,symbol:f,maskId:m,title:r,titleId:o,extra:h,watchable:!0})])}).catch(k)})},e.generateAbstractIcon=function(a){var n=a.children,i=a.attributes,r=a.main,o=a.transform,s=a.styles,c=ue(s);c.length>0&&(i.style=c);var f;return qe(o)&&(f=V("generateAbstractTransformGrouping",{main:r,transform:o,containerWidth:r.width,iconWidth:r.width})),n.push(f||r.icon),{children:n,attributes:i}}}},vr={mixout:function(){return{layer:function(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=n.classes,r=i===void 0?[]:i;return he({type:"layer"},function(){ct("beforeDOMElementCreation",{assembler:a,params:n});var o=[];return a(function(s){Array.isArray(s)?s.map(function(c){o=o.concat(c.abstract)}):o=o.concat(s.abstract)}),[{tag:"span",attributes:{class:["".concat(d.cssPrefix,"-layers")].concat(Dt(r)).join(" ")},children:o}]})}}}},br={mixout:function(){return{counter:function(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=n.title,r=i===void 0?null:i,o=n.classes,s=o===void 0?[]:o,c=n.attributes,f=c===void 0?{}:c,l=n.styles,m=l===void 0?{}:l;return he({type:"counter",content:a},function(){return ct("beforeDOMElementCreation",{content:a,params:n}),Za({content:a.toString(),title:r,extra:{attributes:f,styles:m,classes:["".concat(d.cssPrefix,"-layers-counter")].concat(Dt(s))}})})}}}},yr={mixout:function(){return{text:function(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=n.transform,r=i===void 0?z:i,o=n.title,s=o===void 0?null:o,c=n.classes,f=c===void 0?[]:c,l=n.attributes,m=l===void 0?{}:l,h=n.styles,p=h===void 0?{}:h;return he({type:"text",content:a},function(){return ct("beforeDOMElementCreation",{content:a,params:n}),Jn({content:a,transform:u(u({},z),r),title:s,extra:{attributes:m,styles:p,classes:["".concat(d.cssPrefix,"-layers-text")].concat(Dt(f))}})})}}},provides:function(e){e.generateLayersText=function(a,n){var i=n.title,r=n.transform,o=n.extra,s=null,c=null;if(gi){var f=parseInt(getComputedStyle(a).fontSize,10),l=a.getBoundingClientRect();s=l.width/f,c=l.height/f}return d.autoA11y&&!i&&(o.attributes["aria-hidden"]="true"),Promise.resolve([a,Jn({content:a.innerHTML,width:s,height:c,transform:r,title:i,extra:o,watchable:!0})])}}},wr=new RegExp('"',"ug"),oi=[1105920,1112319];function xr(t){var e=t.replace(wr,""),a=Da(e,0),n=a>=oi[0]&&a<=oi[1],i=e.length===2?e[0]===e[1]:!1;return{value:je(i?e[0]:e),isSecondary:n||i}}function si(t,e){var a="".concat(fa).concat(e.replace(":","-"));return new Promise(function(n,i){if(t.getAttribute(a)!==null)return n();var r=bt(t.children),o=r.filter(function(et){return et.getAttribute(Fe)===e})[0],s=Z.getComputedStyle(t,e),c=s.getPropertyValue("font-family").match(pa),f=s.getPropertyValue("font-weight"),l=s.getPropertyValue("content");if(o&&!c)return t.removeChild(o),n();if(c&&l!=="none"&&l!==""){var m=s.getPropertyValue("content"),h=~["Sharp"].indexOf(c[2])?y:v,p=~["Solid","Regular","Light","Thin","Duotone","Brands","Kit"].indexOf(c[2])?At[h][c[2].toLowerCase()]:ga[h][f],k=xr(m),A=k.value,T=k.isSecondary,F=c[0].startsWith("FontAwesome"),x=Qe(p,A),C=x;if(F){var j=$a(A);j.iconName&&j.prefix&&(x=j.iconName,p=j.prefix)}if(x&&!T&&(!o||o.getAttribute(Ye)!==p||o.getAttribute(Ge)!==C)){t.setAttribute(a,C),o&&t.removeChild(o);var S=ur(),tt=S.extra;tt.attributes[Fe]=e,$e(x,p).then(function(et){var ge=tn(u(u({},S),{},{icons:{main:et,mask:Je()},prefix:p,iconName:C,extra:tt,watchable:!0})),G=b.createElementNS("http://www.w3.org/2000/svg","svg");e==="::before"?t.insertBefore(G,t.firstChild):t.appendChild(G),G.outerHTML=ge.map(function(Xi){return jt(Xi)}).join(`
`),t.removeAttribute(a),n()}).catch(i)}else n()}else n()})}function kr(t){return Promise.all([si(t,"::before"),si(t,"::after")])}function Cr(t){return t.parentNode!==document.head&&!~da.indexOf(t.tagName.toUpperCase())&&!t.getAttribute(Fe)&&(!t.parentNode||t.parentNode.tagName!=="svg")}function ci(t){if(Y)return new Promise(function(e,a){var n=bt(t.querySelectorAll("*")).filter(Cr).map(kr),i=en.begin("searchPseudoElements");Li(),Promise.all(n).then(function(){i(),He(),e()}).catch(function(){i(),He(),a()})})}var _r={hooks:function(){return{mutationObserverCallbacks:function(a){return a.pseudoElementsCallback=ci,a}}},provides:function(e){e.pseudoElements2svg=function(a){var n=a.node,i=n===void 0?b:n;d.searchPseudoElements&&ci(i)}}},li=!1,Ir={mixout:function(){return{dom:{unwatch:function(){Li(),li=!0}}}},hooks:function(){return{bootstrap:function(){ii(Be("mutationObserverCallbacks",{}))},noAuto:function(){sr()},watch:function(a){var n=a.observeMutationsRoot;li?He():ii(Be("mutationObserverCallbacks",{observeMutationsRoot:n}))}}}},fi=function(e){var a={size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0};return e.toLowerCase().split(" ").reduce(function(n,i){var r=i.toLowerCase().split("-"),o=r[0],s=r.slice(1).join("-");if(o&&s==="h")return n.flipX=!0,n;if(o&&s==="v")return n.flipY=!0,n;if(s=parseFloat(s),isNaN(s))return n;switch(o){case"grow":n.size=n.size+s;break;case"shrink":n.size=n.size-s;break;case"left":n.x=n.x-s;break;case"right":n.x=n.x+s;break;case"up":n.y=n.y-s;break;case"down":n.y=n.y+s;break;case"rotate":n.rotate=n.rotate+s;break}return n},a)},Or={mixout:function(){return{parse:{transform:function(a){return fi(a)}}}},hooks:function(){return{parseNodeAttributes:function(a,n){var i=n.getAttribute("data-fa-transform");return i&&(a.transform=fi(i)),a}}},provides:function(e){e.generateAbstractTransformGrouping=function(a){var n=a.main,i=a.transform,r=a.containerWidth,o=a.iconWidth,s={transform:"translate(".concat(r/2," 256)")},c="translate(".concat(i.x*32,", ").concat(i.y*32,") "),f="scale(".concat(i.size/16*(i.flipX?-1:1),", ").concat(i.size/16*(i.flipY?-1:1),") "),l="rotate(".concat(i.rotate," 0 0)"),m={transform:"".concat(c," ").concat(f," ").concat(l)},h={transform:"translate(".concat(o/2*-1," -256)")},p={outer:s,inner:m,path:h};return{tag:"g",attributes:u({},p.outer),children:[{tag:"g",attributes:u({},p.inner),children:[{tag:n.icon.tag,children:n.icon.children,attributes:u(u({},n.icon.attributes),p.path)}]}]}}}},Te={x:0,y:0,width:"100%",height:"100%"};function ui(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return t.attributes&&(t.attributes.fill||e)&&(t.attributes.fill="black"),t}function Sr(t){return t.tag==="g"?t.children:[t]}var Mr={hooks:function(){return{parseNodeAttributes:function(a,n){var i=n.getAttribute("data-fa-mask"),r=i?me(i.split(" ").map(function(o){return o.trim()})):Je();return r.prefix||(r.prefix=Q()),a.mask=r,a.maskId=n.getAttribute("data-fa-mask-id"),a}}},provides:function(e){e.generateAbstractMask=function(a){var n=a.children,i=a.attributes,r=a.main,o=a.mask,s=a.maskId,c=a.transform,f=r.width,l=r.icon,m=o.width,h=o.icon,p=Oa({transform:c,containerWidth:m,iconWidth:f}),k={tag:"rect",attributes:u(u({},Te),{},{fill:"white"})},A=l.children?{children:l.children.map(ui)}:{},T={tag:"g",attributes:u({},p.inner),children:[ui(u({tag:l.tag,attributes:u(u({},l.attributes),p.path)},A))]},F={tag:"g",attributes:u({},p.outer),children:[T]},x="mask-".concat(s||Nt()),C="clip-".concat(s||Nt()),j={tag:"mask",attributes:u(u({},Te),{},{id:x,maskUnits:"userSpaceOnUse",maskContentUnits:"userSpaceOnUse"}),children:[k,F]},S={tag:"defs",children:[{tag:"clipPath",attributes:{id:C},children:Sr(h)},j]};return n.push(S,{tag:"rect",attributes:u({fill:"currentColor","clip-path":"url(#".concat(C,")"),mask:"url(#".concat(x,")")},Te)}),{children:n,attributes:i}}}},Pr={provides:function(e){var a=!1;Z.matchMedia&&(a=Z.matchMedia("(prefers-reduced-motion: reduce)").matches),e.missingIconAbstract=function(){var n=[],i={fill:"currentColor"},r={attributeType:"XML",repeatCount:"indefinite",dur:"2s"};n.push({tag:"path",attributes:u(u({},i),{},{d:"M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"})});var o=u(u({},r),{},{attributeName:"opacity"}),s={tag:"circle",attributes:u(u({},i),{},{cx:"256",cy:"364",r:"28"}),children:[]};return a||s.children.push({tag:"animate",attributes:u(u({},r),{},{attributeName:"r",values:"28;14;28;28;14;28;"})},{tag:"animate",attributes:u(u({},o),{},{values:"1;0;1;1;0;1;"})}),n.push(s),n.push({tag:"path",attributes:u(u({},i),{},{opacity:"1",d:"M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"}),children:a?[]:[{tag:"animate",attributes:u(u({},o),{},{values:"1;0;0;0;0;1;"})}]}),a||n.push({tag:"path",attributes:u(u({},i),{},{opacity:"0",d:"M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"}),children:[{tag:"animate",attributes:u(u({},o),{},{values:"0;0;1;1;0;0;"})}]}),{tag:"g",attributes:{class:"missing"},children:n}}}},Ar={hooks:function(){return{parseNodeAttributes:function(a,n){var i=n.getAttribute("data-fa-symbol"),r=i===null?!1:i===""?!0:i;return a.symbol=r,a}}}},Er=[Pa,gr,vr,br,yr,_r,Ir,Or,Mr,Pr,Ar];Wa(Er,{mixoutsTo:P});var So=P.noAuto,Mo=P.config,Po=P.library,Ao=P.dom,Ri=P.parse,Eo=P.findIconDefinition,To=P.toHtml,zi=P.icon,No=P.layer,Tr=P.text,Nr=P.counter;var Dr=["*"],Fr=t=>{throw new Error(`Could not find icon with iconName=${t.iconName} and prefix=${t.prefix} in the icon library.`)},jr=()=>{throw new Error("Property `icon` is required for `fa-icon`/`fa-duotone-icon` components.")},Lr=t=>{let e={[`fa-${t.animation}`]:t.animation!=null&&!t.animation.startsWith("spin"),"fa-spin":t.animation==="spin"||t.animation==="spin-reverse","fa-spin-pulse":t.animation==="spin-pulse"||t.animation==="spin-pulse-reverse","fa-spin-reverse":t.animation==="spin-reverse"||t.animation==="spin-pulse-reverse","fa-pulse":t.animation==="spin-pulse"||t.animation==="spin-pulse-reverse","fa-fw":t.fixedWidth,"fa-border":t.border,"fa-inverse":t.inverse,"fa-layers-counter":t.counter,"fa-flip-horizontal":t.flip==="horizontal"||t.flip==="both","fa-flip-vertical":t.flip==="vertical"||t.flip==="both",[`fa-${t.size}`]:t.size!==null,[`fa-rotate-${t.rotate}`]:t.rotate!==null,[`fa-pull-${t.pull}`]:t.pull!==null,[`fa-stack-${t.stackItemSize}`]:t.stackItemSize!=null};return Object.keys(e).map(a=>e[a]?a:null).filter(a=>a)},Br=t=>t.prefix!==void 0&&t.iconName!==void 0,Rr=(t,e)=>Br(t)?t:typeof t=="string"?{prefix:e,iconName:t}:{prefix:t[0],iconName:t[1]},zr=(()=>{let e=class e{constructor(){this.defaultPrefix="fas",this.fallbackIcon=null}};e.\u0275fac=function(i){return new(i||e)},e.\u0275prov=_({token:e,factory:e.\u0275fac,providedIn:"root"});let t=e;return t})(),$r=(()=>{let e=class e{constructor(){this.definitions={}}addIcons(...n){for(let i of n){i.prefix in this.definitions||(this.definitions[i.prefix]={}),this.definitions[i.prefix][i.iconName]=i;for(let r of i.icon[2])typeof r=="string"&&(this.definitions[i.prefix][r]=i)}}addIconPacks(...n){for(let i of n){let r=Object.keys(i).map(o=>i[o]);this.addIcons(...r)}}getIconDefinition(n,i){return n in this.definitions&&i in this.definitions[n]?this.definitions[n][i]:null}};e.\u0275fac=function(i){return new(i||e)},e.\u0275prov=_({token:e,factory:e.\u0275fac,providedIn:"root"});let t=e;return t})(),Ur=(()=>{let e=class e{constructor(){this.stackItemSize="1x"}ngOnChanges(n){if("size"in n)throw new Error('fa-icon is not allowed to customize size when used inside fa-stack. Set size on the enclosing fa-stack instead: <fa-stack size="4x">...</fa-stack>.')}};e.\u0275fac=function(i){return new(i||e)},e.\u0275dir=ft({type:e,selectors:[["fa-icon","stackItemSize",""],["fa-duotone-icon","stackItemSize",""]],inputs:{stackItemSize:"stackItemSize",size:"size"},standalone:!0,features:[$]});let t=e;return t})(),Hr=(()=>{let e=class e{constructor(n,i){this.renderer=n,this.elementRef=i}ngOnInit(){this.renderer.addClass(this.elementRef.nativeElement,"fa-stack")}ngOnChanges(n){"size"in n&&(n.size.currentValue!=null&&this.renderer.addClass(this.elementRef.nativeElement,`fa-${n.size.currentValue}`),n.size.previousValue!=null&&this.renderer.removeClass(this.elementRef.nativeElement,`fa-${n.size.previousValue}`))}};e.\u0275fac=function(i){return new(i||e)(g(wn),g(at))},e.\u0275cmp=K({type:e,selectors:[["fa-stack"]],inputs:{size:"size"},standalone:!0,features:[$,Ce],ngContentSelectors:Dr,decls:1,vars:0,template:function(i,r){i&1&&(Cn(),_n(0))},encapsulation:2});let t=e;return t})(),pe=(()=>{let e=class e{set spin(n){this.animation=n?"spin":void 0}set pulse(n){this.animation=n?"spin-pulse":void 0}constructor(n,i,r,o,s){this.sanitizer=n,this.config=i,this.iconLibrary=r,this.stackItem=o,this.classes=[],s!=null&&o==null&&console.error('FontAwesome: fa-icon and fa-duotone-icon elements must specify stackItemSize attribute when wrapped into fa-stack. Example: <fa-icon stackItemSize="2x"></fa-icon>.')}ngOnChanges(n){if(this.icon==null&&this.config.fallbackIcon==null){jr();return}if(n){let i=this.icon!=null?this.icon:this.config.fallbackIcon,r=this.findIconDefinition(i);if(r!=null){let o=this.buildParams();this.renderIcon(r,o)}}}render(){this.ngOnChanges({})}findIconDefinition(n){let i=Rr(n,this.config.defaultPrefix);if("icon"in i)return i;let r=this.iconLibrary.getIconDefinition(i.prefix,i.iconName);return r??(Fr(i),null)}buildParams(){let n={flip:this.flip,animation:this.animation,border:this.border,inverse:this.inverse,size:this.size||null,pull:this.pull||null,rotate:this.rotate||null,fixedWidth:typeof this.fixedWidth=="boolean"?this.fixedWidth:this.config.fixedWidth,stackItemSize:this.stackItem!=null?this.stackItem.stackItemSize:null},i=typeof this.transform=="string"?Ri.transform(this.transform):this.transform;return{title:this.title,transform:i,classes:[...Lr(n),...this.classes],mask:this.mask!=null?this.findIconDefinition(this.mask):null,styles:this.styles!=null?this.styles:{},symbol:this.symbol,attributes:{role:this.a11yRole}}}renderIcon(n,i){let r=zi(n,i);this.renderedIconHTML=this.sanitizer.bypassSecurityTrustHtml(r.html.join(`
`))}};e.\u0275fac=function(i){return new(i||e)(g(Nn),g(zr),g($r),g(Ur,8),g(Hr,8))},e.\u0275cmp=K({type:e,selectors:[["fa-icon"]],hostAttrs:[1,"ng-fa-icon"],hostVars:2,hostBindings:function(i,r){i&2&&(kn("innerHTML",r.renderedIconHTML,yn),Ht("title",r.title))},inputs:{icon:"icon",title:"title",animation:"animation",spin:"spin",pulse:"pulse",mask:"mask",styles:"styles",flip:"flip",size:"size",pull:"pull",border:"border",inverse:"inverse",symbol:"symbol",rotate:"rotate",fixedWidth:"fixedWidth",classes:"classes",transform:"transform",a11yRole:"a11yRole"},standalone:!0,features:[$,Ce],decls:0,vars:0,template:function(i,r){},encapsulation:2});let t=e;return t})();var an=(()=>{let e=class e{};e.\u0275fac=function(i){return new(i||e)},e.\u0275mod=O({type:e}),e.\u0275inj=I({});let t=e;return t})();function Vr(t,e){if(t&1&&(N(0,"div",6),Wt(1,"fa-icon",7),R()),t&2){let a=E(2),n=Ct(1);B(),M("icon",a.icon||n.icon)("fixedWidth",!0)}}function Yr(t,e){if(t&1&&(N(0,"div",8),In(1),R()),t&2){let a=E(2),n=Ct(1);B(),On(" ",a.text||n.text," ")}}function Gr(t,e){if(t&1&&(N(0,"div",3),ut(1,Vr,2,2,"div",4)(2,Yr,2,1,"div",5),R()),t&2){let a=E(),n=Ct(1);B(),M("ngIf",a.showIcon&&n.icon),B(),M("ngIf",a.showText)}}var Ui=(()=>{let e=class e{get buttonClass(){return`sb-button sb-${this.theme}`}constructor(n){this._share=n,this.redirectUrl=this._share.config.redirectUrl,this.showIcon=!0,this.showText=!1,this.theme=this._share.config.theme,this.opened=new L,this.closed=new L}};e.\u0275fac=function(i){return new(i||e)(g(It))},e.\u0275cmp=K({type:e,selectors:[["share-button"]],hostVars:2,hostBindings:function(i,r){i&2&&xn(r.buttonClass)},inputs:{button:"button",url:"url",title:"title",description:"description",image:"image",tags:"tags",redirectUrl:"redirectUrl",autoSetMeta:"autoSetMeta",showIcon:"showIcon",showText:"showText",text:"text",icon:"icon",theme:"theme",disabled:"disabled"},outputs:{opened:"opened",closed:"closed"},decls:3,vars:14,consts:[["btn","shareButton"],["type","button",1,"sb-wrapper",3,"opened","closed","shareButton","url","image","title","description","tags","redirectUrl","autoSetMeta","disabled"],["class","sb-content",4,"ngIf"],[1,"sb-content"],["class","sb-icon",4,"ngIf"],["class","sb-text",4,"ngIf"],[1,"sb-icon"],[3,"icon","fixedWidth"],[1,"sb-text"]],template:function(i,r){if(i&1){let o=kt();N(0,"button",1,0),U("opened",function(c){return nt(o),it(r.opened.emit(c))})("closed",function(c){return nt(o),it(r.closed.emit(c))}),ut(2,Gr,3,2,"div",2),R()}if(i&2){let o=Ct(1);xe("sb-show-icon",r.showIcon)("sb-show-text",r.showText),M("shareButton",r.button)("url",r.url)("image",r.image)("title",r.title)("description",r.description)("tags",r.tags)("redirectUrl",r.redirectUrl)("autoSetMeta",r.autoSetMeta)("disabled",r.disabled),B(2),M("ngIf",o)}},dependencies:[Bn,pe,Yt],styles:["[button=facebook][_nghost-%COMP%], [button=facebook]   [_nghost-%COMP%]{--button-color: #4267B2}[button=twitter][_nghost-%COMP%], [button=twitter]   [_nghost-%COMP%]{--button-color: #00acee}[button=google][_nghost-%COMP%], [button=google]   [_nghost-%COMP%]{--button-color: #db4437}[button=mix][_nghost-%COMP%], [button=mix]   [_nghost-%COMP%]{--button-color: #ff8226}[button=line][_nghost-%COMP%], [button=line]   [_nghost-%COMP%]{--button-color: #00b900}[button=linkedin][_nghost-%COMP%], [button=linkedin]   [_nghost-%COMP%]{--button-color: #006fa6}[button=pinterest][_nghost-%COMP%], [button=pinterest]   [_nghost-%COMP%]{--button-color: #bd081c}[button=reddit][_nghost-%COMP%], [button=reddit]   [_nghost-%COMP%]{--button-color: #ff4006}[button=tumblr][_nghost-%COMP%], [button=tumblr]   [_nghost-%COMP%]{--button-color: #36465d}[button=whatsapp][_nghost-%COMP%], [button=whatsapp]   [_nghost-%COMP%]{--button-color: #25d366}[button=messenger][_nghost-%COMP%], [button=messenger]   [_nghost-%COMP%]{--button-color: #0080FF}[button=telegram][_nghost-%COMP%], [button=telegram]   [_nghost-%COMP%]{--button-color: #0088cc}[button=xing][_nghost-%COMP%], [button=xing]   [_nghost-%COMP%]{--button-color: #006567}[button=sms][_nghost-%COMP%], [button=sms]   [_nghost-%COMP%]{--button-color: #20c16c}[button=email][_nghost-%COMP%], [button=email]   [_nghost-%COMP%]{--button-color: #FF961C}[button=viber][_nghost-%COMP%], [button=viber]   [_nghost-%COMP%]{--button-color: #665ca7}[button=vk][_nghost-%COMP%], [button=vk]   [_nghost-%COMP%]{--button-color: #4C75A3}[button=copy][_nghost-%COMP%], [button=copy]   [_nghost-%COMP%]{--button-color: #607D8B}[button=print][_nghost-%COMP%], [button=print]   [_nghost-%COMP%]{--button-color: #765AA2}[button=expand][_nghost-%COMP%], [button=expand]   [_nghost-%COMP%]{--button-color: #FF6651}button[_ngcontent-%COMP%]{cursor:pointer;position:relative;outline:0;-webkit-print-color-adjust:exact;margin:var(--sb-margin, .3125em);padding:var(--sb-padding, 0);min-width:var(--sb-min-width, 4.125em);height:var(--sb-height, 2.5em);color:var(--sb-color, #fff);background:var(--sb-background);font-size:var(--sb-font-size, 13px);line-height:var(--sb-line-height, 2.571em);border:var(--sb-border);border-radius:var(--sb-border-radius);transition:var(--sb-transition);box-shadow:var(--sb-box-shadow);text-shadow:var(--sb-text-shadow);overflow:var(--sb-overflow)}.sb-icon[_ngcontent-%COMP%], .sb-text[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;user-select:none}.sb-content[_ngcontent-%COMP%]{flex:1;display:flex;height:100%;width:100%;position:relative}.sb-text[_ngcontent-%COMP%]{flex:1;height:100%;white-space:nowrap;padding:var(--sb-text-padding, 0 .7em);font-weight:var(--sb-font-weight, bold)}.sb-icon[_ngcontent-%COMP%]{text-align:center;width:100%;height:100%;min-width:2em;font-size:var(--sb-icon-size, 1.2em)}"],changeDetection:0});let t=e;return t})(),rn=(()=>{let e=class e{static withConfig(n){return{ngModule:e,providers:[{provide:mt,useValue:n}]}}};e.\u0275fac=function(i){return new(i||e)},e.\u0275mod=O({type:e}),e.\u0275inj=I({imports:[Me,an,Gt,Me,an]});let t=e;return t})();function Kr(t,e){if(t&1){let a=kt();N(0,"share-button",3),U("opened",function(i){nt(a);let r=E(2);return it(r.opened.emit(i))})("closed",function(i){nt(a);let r=E(2);return it(r.closed.emit(i))}),R()}if(t&2){let a=e.$implicit,n=E(2);M("button",a)("theme",n.theme)("url",n.url)("title",n.title)("description",n.description)("image",n.image)("tags",n.tags)("redirectUrl",n.redirectUrl)("autoSetMeta",n.autoSetMeta)("showIcon",n.showIcon)("showText",n.showText)("disabled",n.disabled)}}function qr(t,e){if(t&1){let a=kt();N(0,"expand-button",4),U("toggle",function(i){nt(a);let r=E(2);return it(r.updateState({expanded:i}))}),R()}if(t&2){let a=E().$implicit,n=E();ke("sb-button sb-",n.theme,""),M("expanded",a.expanded)("moreIcon",a.moreIcon)("lessIcon",a.lessIcon)("moreAriaLabel",a.moreAriaLabel)("lessAriaLabel",a.lessAriaLabel)}}function Zr(t,e){if(t&1&&(N(0,"div"),ut(1,Kr,1,12,"share-button",1)(2,qr,1,8,"expand-button",2),R()),t&2){let a=e.$implicit,n=E();ke("sb-group sb-",n.theme,""),B(),M("ngForOf",a.selectedButtons),B(),M("ngIf",a.shownCount<a.userButtons.length)}}var Qr=(()=>{let e=class e{constructor(n){this.toggle=new L,n.nativeElement.style.setProperty("--button-color","#FF6651")}};e.\u0275fac=function(i){return new(i||e)(g(at))},e.\u0275cmp=K({type:e,selectors:[["expand-button"]],inputs:{moreIcon:"moreIcon",lessIcon:"lessIcon",expanded:"expanded",moreAriaLabel:"moreAriaLabel",lessAriaLabel:"lessAriaLabel"},outputs:{toggle:"toggle"},decls:4,vars:2,consts:[[1,"sb-wrapper","sb-expand","sb-show-icon",3,"click"],[1,"sb-content"],[1,"sb-icon"],[3,"icon"]],template:function(i,r){i&1&&(N(0,"button",0),U("click",function(){return r.toggle.emit(!r.expanded)}),N(1,"div",1)(2,"div",2),Wt(3,"fa-icon",3),R()()()),i&2&&(Ht("aria-label",r.expanded?r.lessAriaLabel:r.moreAriaLabel),B(3),M("icon",r.expanded?r.lessIcon:r.moreIcon))},dependencies:[pe],styles:["[button=facebook][_nghost-%COMP%], [button=facebook]   [_nghost-%COMP%]{--button-color: #4267B2}[button=twitter][_nghost-%COMP%], [button=twitter]   [_nghost-%COMP%]{--button-color: #00acee}[button=google][_nghost-%COMP%], [button=google]   [_nghost-%COMP%]{--button-color: #db4437}[button=mix][_nghost-%COMP%], [button=mix]   [_nghost-%COMP%]{--button-color: #ff8226}[button=line][_nghost-%COMP%], [button=line]   [_nghost-%COMP%]{--button-color: #00b900}[button=linkedin][_nghost-%COMP%], [button=linkedin]   [_nghost-%COMP%]{--button-color: #006fa6}[button=pinterest][_nghost-%COMP%], [button=pinterest]   [_nghost-%COMP%]{--button-color: #bd081c}[button=reddit][_nghost-%COMP%], [button=reddit]   [_nghost-%COMP%]{--button-color: #ff4006}[button=tumblr][_nghost-%COMP%], [button=tumblr]   [_nghost-%COMP%]{--button-color: #36465d}[button=whatsapp][_nghost-%COMP%], [button=whatsapp]   [_nghost-%COMP%]{--button-color: #25d366}[button=messenger][_nghost-%COMP%], [button=messenger]   [_nghost-%COMP%]{--button-color: #0080FF}[button=telegram][_nghost-%COMP%], [button=telegram]   [_nghost-%COMP%]{--button-color: #0088cc}[button=xing][_nghost-%COMP%], [button=xing]   [_nghost-%COMP%]{--button-color: #006567}[button=sms][_nghost-%COMP%], [button=sms]   [_nghost-%COMP%]{--button-color: #20c16c}[button=email][_nghost-%COMP%], [button=email]   [_nghost-%COMP%]{--button-color: #FF961C}[button=viber][_nghost-%COMP%], [button=viber]   [_nghost-%COMP%]{--button-color: #665ca7}[button=vk][_nghost-%COMP%], [button=vk]   [_nghost-%COMP%]{--button-color: #4C75A3}[button=copy][_nghost-%COMP%], [button=copy]   [_nghost-%COMP%]{--button-color: #607D8B}[button=print][_nghost-%COMP%], [button=print]   [_nghost-%COMP%]{--button-color: #765AA2}[button=expand][_nghost-%COMP%], [button=expand]   [_nghost-%COMP%]{--button-color: #FF6651}button[_ngcontent-%COMP%]{cursor:pointer;position:relative;outline:0;-webkit-print-color-adjust:exact;margin:var(--sb-margin, .3125em);padding:var(--sb-padding, 0);min-width:var(--sb-min-width, 4.125em);height:var(--sb-height, 2.5em);color:var(--sb-color, #fff);background:var(--sb-background);font-size:var(--sb-font-size, 13px);line-height:var(--sb-line-height, 2.571em);border:var(--sb-border);border-radius:var(--sb-border-radius);transition:var(--sb-transition);box-shadow:var(--sb-box-shadow);text-shadow:var(--sb-text-shadow);overflow:var(--sb-overflow)}.sb-icon[_ngcontent-%COMP%], .sb-text[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;-webkit-user-select:none;-moz-user-select:none;user-select:none}.sb-content[_ngcontent-%COMP%]{flex:1;display:flex;height:100%;width:100%;position:relative}.sb-text[_ngcontent-%COMP%]{flex:1;height:100%;white-space:nowrap;padding:var(--sb-text-padding, 0 .7em);font-weight:var(--sb-font-weight, bold)}.sb-icon[_ngcontent-%COMP%]{text-align:center;width:100%;height:100%;min-width:2em;font-size:var(--sb-icon-size, 1.2em)}"],changeDetection:0});let t=e;return t})(),as=(()=>{let e=class e{constructor(n){this._share=n,this._state$=new Rt({includedButtons:[],excludedButtons:[],userButtons:[],selectedButtons:[],expanded:!0,shownCount:Object.keys(qt).length}),this._configSub$=on.EMPTY,this.theme=this._share.config.theme,this.redirectUrl=this._share.config.redirectUrl,this.showIcon=!0,this.showText=!1,this.opened=new L,this.closed=new L}ngOnInit(){this.state$=this._state$.pipe(ln(n=>{let i=n.includedButtons&&n.includedButtons.length?n.includedButtons:n.userButtons,r=n.excludedButtons?i.filter(s=>n.excludedButtons.indexOf(s)<0):i,o=r.slice(0,n.expanded?r.length:n.shownCount);return{userButtons:r,selectedButtons:o,expanded:n.expanded,shownCount:n.shownCount,moreIcon:n.moreIcon,lessIcon:n.lessIcon,moreAriaLabel:n.moreAriaLabel,lessAriaLabel:n.lessAriaLabel}})),this._configSub$=this._share.config$.subscribe(n=>{let r=(n.include.length?n.include:Object.keys(qt)).filter(o=>n.exclude.indexOf(o)<0);this.updateState({userButtons:r,expanded:!1,moreIcon:n.moreButtonIcon,lessIcon:n.lessButtonIcon,moreAriaLabel:n.moreButtonAriaLabel,lessAriaLabel:n.lessButtonAriaLabel})})}ngOnChanges(n){(n.include&&n.include.currentValue!==n.include.previousValue||n.exclude&&n.exclude.currentValue!==n.exclude.previousValue||n.show&&n.show.currentValue!==n.show.previousValue)&&this.updateState({includedButtons:this.include,excludedButtons:this.exclude,shownCount:this.show})}ngOnDestroy(){this._configSub$.unsubscribe(),this._state$.complete()}updateState(n){this._state$.next(ve(ve({},this._state$.value),n))}};e.\u0275fac=function(i){return new(i||e)(g(It))},e.\u0275cmp=K({type:e,selectors:[["share-buttons"]],inputs:{theme:"theme",include:"include",exclude:"exclude",show:"show",url:"url",title:"title",description:"description",image:"image",tags:"tags",redirectUrl:"redirectUrl",autoSetMeta:"autoSetMeta",showIcon:"showIcon",showText:"showText",disabled:"disabled"},outputs:{opened:"opened",closed:"closed"},features:[$],decls:2,vars:3,consts:[[3,"class",4,"ngIf"],[3,"button","theme","url","title","description","image","tags","redirectUrl","autoSetMeta","showIcon","showText","disabled","opened","closed",4,"ngFor","ngForOf"],[3,"class","expanded","moreIcon","lessIcon","moreAriaLabel","lessAriaLabel","toggle",4,"ngIf"],[3,"opened","closed","button","theme","url","title","description","image","tags","redirectUrl","autoSetMeta","showIcon","showText","disabled"],[3,"toggle","expanded","moreIcon","lessIcon","moreAriaLabel","lessAriaLabel"]],template:function(i,r){i&1&&(ut(0,Zr,3,5,"div",0),Sn(1,"async")),i&2&&M("ngIf",Mn(1,1,r.state$))},dependencies:[Ui,Pn,Yt,Qr,An],styles:["[_nghost-%COMP%]{display:inherit}.sb-group[_ngcontent-%COMP%], .sb-button[_ngcontent-%COMP%]{display:inline-flex;align-items:flex-start}.sb-group[_ngcontent-%COMP%]{flex-wrap:wrap}"],changeDetection:0});let t=e;return t})(),rs=(()=>{let e=class e{static withConfig(n){return{ngModule:e,providers:[{provide:mt,useValue:n}]}}};e.\u0275fac=function(i){return new(i||e)},e.\u0275mod=O({type:e}),e.\u0275inj=I({imports:[rn,Gt,rn]});let t=e;return t})();function Jr(t){return typeof t<"u"&&t!==null}function to(t){return t!=null&&`${t}`!="false"}function eo(t){let e=new Date(t);if(!Number.isNaN(e.valueOf()))return e;let a=String(t).match(/\d+/g);if(a===null||a.length<=2)return e;{let[n,i,...r]=a.map(o=>parseInt(o,10));return new Date(Date.UTC(n,i-1,...r))}}var Lt=60,Bt=Lt*60,yt=Bt*24,Hi=yt*7,Wi=yt*30,Vi=yt*365,no=(()=>{let e=class e{constructor(){this.changes=new lt}};e.\u0275fac=function(i){return new(i||e)},e.\u0275prov=_({token:e,factory:e.\u0275fac});let t=e;return t})(),io=function(t){let e=Date.now(),a=Math.round(Math.abs(e-t)/1e3),n=t<e?"ago":"from now",[i,r]=a<Lt?[Math.round(a),"second"]:a<Bt?[Math.round(a/Lt),"minute"]:a<yt?[Math.round(a/Bt),"hour"]:a<Hi?[Math.round(a/yt),"day"]:a<Wi?[Math.round(a/Hi),"week"]:a<Vi?[Math.round(a/Wi),"month"]:[Math.round(a/Vi),"year"];return{value:i,unit:r,suffix:n}},wt=class{},Yi=(()=>{let e=class e extends wt{format(n){let{suffix:i,value:r,unit:o}=io(n);return this.parse(r,o,i)}parse(n,i,r){return n!==1&&(i+="s"),n+" "+i+" "+r}};e.\u0275fac=(()=>{let n;return function(r){return(n||(n=Ut(e)))(r||e)}})(),e.\u0275prov=_({token:e,factory:e.\u0275fac});let t=e;return t})();var xt=class{},Gi=(()=>{let e=class e extends xt{tick(n){return zt(0).pipe(hn(()=>{let i=Date.now(),r=Math.round(Math.abs(i-n)/1e3),o=r<Lt?1e3:r<Bt?1e3*Lt:r<yt?1e3*Bt:0;return o?fn(o):cn()}),pn(1))}};e.\u0275fac=(()=>{let n;return function(r){return(n||(n=Ut(e)))(r||e)}})(),e.\u0275prov=_({token:e,factory:e.\u0275fac});let t=e;return t})();var fs=(()=>{let e=class e{constructor(n,i,r,o){this.clock=o,this.live=!0,this.stateChanges=new lt,n&&(this.intlSubscription=n.changes.subscribe(()=>this.stateChanges.next())),this.stateChanges.subscribe(()=>{this.value=r.format(this.date),i.markForCheck()})}transform(n,...i){let r=eo(n).valueOf(),o;if(o=Jr(i[0])?to(i[0]):this.live,this.date===r&&this.live===o)return this.value;if(this.date=r,this.live=o,this.date)this.clockSubscription&&(this.clockSubscription.unsubscribe(),this.clockSubscription=void 0),this.clockSubscription=this.clock.tick(this.date).pipe(un(()=>this.live,this)).subscribe(()=>this.stateChanges.next()),this.stateChanges.next();else throw new SyntaxError(`Wrong parameter in TimeagoPipe. Expected a valid date, received: ${n}`);return this.value}ngOnDestroy(){this.intlSubscription&&(this.intlSubscription.unsubscribe(),this.intlSubscription=void 0),this.clockSubscription&&(this.clockSubscription.unsubscribe(),this.clockSubscription=void 0),this.stateChanges.complete()}};e.\u0275fac=function(i){return new(i||e)(g(no,24),g(Vt,16),g(wt,16),g(xt,16))},e.\u0275pipe=vn({name:"timeago",type:e,pure:!1}),e.\u0275prov=_({token:e,factory:e.\u0275fac});let t=e;return t})(),us=(()=>{let e=class e{static forRoot(n={}){return{ngModule:e,providers:[n.clock||{provide:xt,useClass:Gi},n.intl||[],n.formatter||{provide:wt,useClass:Yi}]}}static forChild(n={}){return{ngModule:e,providers:[n.clock||{provide:xt,useClass:Gi},n.intl||[],n.formatter||{provide:wt,useClass:Yi}]}}};e.\u0275fac=function(i){return new(i||e)},e.\u0275mod=O({type:e}),e.\u0275inj=I({});let t=e;return t})();export{fs as a,us as b,$r as c,an as d,as as e,rs as f};
